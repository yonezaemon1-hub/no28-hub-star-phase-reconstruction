# External independent audit request — No.28

This is a REQUEST FOR REVIEW, not evidence that independent review occurred.

Please scrutinize in order:
1. Raw hub-phase sample complexity upper-bound proof: show or refute the existence of an N-independent holomorphic time disk; the complex Picard contraction; the E_2 Bernstein-ellipse inclusion; endpoint Chebyshev second-derivative bias and noise amplification. Find an explicit counterexample if a step is false.
2. Lower bound against adaptive resets: check the l1 Lipschitz / Dini derivatives, hub bound, Gaussian conditional-KL chain rule and Pinsker constant under shared reset histories.
3. Target-edge recovery: directly derive Q=a+2d from the Kuramoto ODE. Check permutation-based two-level one-probe impossibility across all m>=3 and weighted-case caveats.
4. Preparation jitter counterexample: verify two-jet collision as m increases; determine whether claim is incorrectly extended to the full phase trajectory.
5. Prior-art theorem-level comparison: could the specialized parity identity or N^4 scaling be immediate corollaries of known inverse network/graph query/statistical system-identification theorems? Cite exact theorem, assumptions, and differences.
6. Verify hashes and rerun exact scripts, cross-check against an independently authored implementation.

Return a strict PASS/FAIL/INCONCLUSIVE for each assertion; exclude publication or priority claims without thorough evidence. Do not expand the project into new theorems or new runtime/frameworks.
