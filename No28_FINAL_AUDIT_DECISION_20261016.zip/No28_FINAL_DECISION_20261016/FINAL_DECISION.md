# No.28 — Final scope-limited technical and novelty audit (2026-10-16)

## Decision

- **Technical mathematics (model-restricted): CONDITIONAL PASS** for exact three-level, single-probe edge retrieval and the normalized fixed-horizon two-hypothesis noise lower bound; algebraic identities were independently checked in SymPy. Previous original numerical scripts were rerun successfully.
- **Raw-phase sample-complexity upper bound: CONDITIONAL / PROOF-SKETCH**, not a published theorem or independently certified full proof. The analytic complex-time neighborhood, Chebyshev interpolation, Markov inequality, Lebesgue constant, and noise averaging argument supports `M = O(sigma^2 N^4 polylog N)` as an existence result with fixed sigma>0 and fixed delta (plus additive terms if noise is tiny). The full numerical constants have not been machine-certified, and there is no experimental hardware validation.
- **Novelty: INCONCLUSIVE, leaning towards combination / model-specific specialization of known methods**. The present audit did not locate the exact identity or N^4 rates stated verbatim in the literature reviewed, but key conceptual/mathematical mechanisms pre-exist.
- **Independent Claude/human peer review: NOT PERFORMED in this audit.** Do not label this a second-model or human audit.
- **Research/publication disposition: close No.28 as an archival INCONCLUSIVE research record. Do NOT present as a validated novel journal paper. Public posting is deferred to the owner's authorization / external review.**

## Scope and crucial assumptions

All claims here use the symmetric binary hub-star Kuramoto ODE with exactly known, uniform edge coupling `k=1/N`, zero intrinsic frequencies (for the upper bound), a hub connected to every leaf, unknown binary leaf edges, and exact known reset phases. Repetitions reuse the same fixed graph and initial state. Only unwrapped hub phase is observable. Raw-phase noises are **independent across readings**, Gaussian with variance sigma². Time horizon T is constant as N increases and there is no dynamical/process noise. N includes the hub.

### Checked central identity

Reset leaf 1 to pi, leaf 2 to phi=acos(-1/3), other leaves and hub to 0. Write a=a_12, d=sum_{j>=3}a_2j, s=sin(phi). Then

    h''(0) = k² s[(11/3-m)+(2/3)a+(4/3)d]
    Q = 3 h''(0)/(2 k² s)+(3m-11)/2 = a + 2d.

Thus `Q mod 2` recovers a for exact observation (if the unknown leaf weights are binary). Three reset levels suffice for one experiment; a single **two-level** reset cannot uniformly recover the target edge when m>=3, by phase-preserving leaf permutations / synchronized-edge indistinguishability. The three-level result does not resolve the original **two-binary-probe** question for all m.

Measured second-jet class gap is `A=(4 sqrt(2)/9) k²`, so worst-case absolute error below `A/2` suffices for nearest-lattice decoding, but this is not a guarantee about noisy raw-phase data or reset-phase errors.

### Noise lower and upper bounds

- Two graphs differing only by a leaf edge satisfy `|h_1(t)-h_0(t)| <= k²(exp(t)-1)²` over t in [0,T]; Gronwall integral independently rederived. Thus adversarial trajectory errors larger than half the bound admit indistinguishable outputs.
- Gaussian raw-hub-phase observations: conditional KL bounded by `M B²/(2 sigma²)` where `B=k²(exp(T)-1)²`. Two-point testing error <=1/4 on both hypotheses requires `M>=sigma²/B²`, giving Omega(sigma² N⁴) for fixed sigma,T. This holds against adaptive reset/time selection using equal shared control histories and independently sampled noise.
- Direct Gaussian second-jet observations: exact parity decoder needs `R>= (81/4) sigma² N⁴ log(2/delta)` under the usual Gaussian tail bound. This is **a different observation model** from raw phase.
- Raw hub-phase upper: analytic-time uniformity + Chebyshev-Lobatto time sampling n=O(log N), repeating Gaussian readings at each time point R=O(sigma² N⁴ polylog N), yields total `M=O(sigma² N⁴ (log N)^9 (log log N)^2 log((log N)/delta))` under fixed sigma>0, delta in (0,1) and N sufficiently large. This is a conservative asymptotic existence proof, not an efficient implementation or hardware validation. No uniform performance with uncontrolled reset errors is established.
- Unknown preparation jitter: a constructed pair of graphs with opposite target-edge status can have identical h'(0),h''(0) after allowing reset errors of order 1/m; this does **not** establish indistinguishability of complete time trajectories or of other probe designs.

### Independent work in the current audit

1. All available prior relevant ZIP containers passed `unzip -t`.
2. Each prior working-folder SHA256SUMS passed (`sha256sum -c`).
3. Ran the ternary exact verifier: all 33,864 m=3..6 graphs and 35,000 sampled graphs at m=7,8,12,20 PASS (these are previous authors' scripts, **not** independent external proof).
4. Ran the stdlib robustness verifier: 6 jitter-collision instances and 12 trajectory tests PASS.
5. Ran separate stdlib raw-hub RK4 verification: 6 graph cases PASS.
6. Reran SciPy raw-phase simulator (N=8,16,32,64; 64 graphs, 3,200 trials per N per budget): results exactly reproduce prior JSON; fixed8 success counts 3130,1698,1637,1578, versus N^4-budget success 3134,3136,3134,3132 out of 3200.
7. Wrote **new** `independent_equation_check.py` with SymPy-based symbolic calculation, independent of previous verifier functions. It checks hub second derivative, integer code, generic bounded-weight phase ratio, integrated Gronwall expression and Gaussian direct-jet tail constant. All pass.

### Literature / overlap reviewed

Primary URLs:
- Levnajić–Pikovsky 2011, phase-reset network reconstruction: https://doi.org/10.1103/PhysRevLett.107.034101
- Pikovsky 2018, reconstruction of phase-dynamics networks: https://doi.org/10.1016/j.physleta.2017.11.012
- Kiran–Pereira, *Unique Reconstruction From Mean-Field Measurements*: https://arxiv.org/html/2506.00301 (localized initial perturbations / low-dimensional aggregated observation)
- Boullé–Halikias–Otto–Townsend 2026, one-shot system identification: https://arxiv.org/html/2607.15832
- Guan–Berry–Sauer 2018, partial-observation conditioning: https://doi.org/10.1103/PhysRevE.98.022318
- Berry–Sauer 2025, noisy reconstruction from partial observations: https://doi.org/10.1137/24M1655780
- Reddy–Weideman 2005, analytic Chebyshev derivative error: https://doi.org/10.1137/040603280

The original studies are not exact copies of the restricted parity identity or normalized worst-case N⁴ pair bound, as far as checked. But the current contribution looks heavily like a combination of known ingredients. The literature check is targeted, not exhaustive; no priority or patent claims.

## Closed vs open

CLOSED (for this round): scope-limited exact-ternary recovery, model-restricted lower bound, numerical illustration, and research archival decision.

NOT ESTABLISHED: generic binary two-probe sufficiency for all m; exact minimax logarithmic factors; usefulness with unknown frequencies/coupling, process noise, inaccessible precise node initialization, unknown phase jitter; novelty under full scholarly review.

**No additional experiments / theorem extensions are authorized in this final-audit phase.** The next action is outside review only if the owner chooses to reopen it. Keep distinct from NAGI and avoid calling this a deployed software/product.
