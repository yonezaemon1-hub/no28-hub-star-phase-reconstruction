# No.28 final closure bundle — 2026-10-16

Decision: technical conditional PASS / novelty INCONCLUSIVE / No.28 paper publication HOLD / archival record complete in Library (not external GitHub).

- FINAL_DECISION.md — model, exact claim boundaries, reproductions, novelty finding, final disposition.
- CLAUDE_REVIEW_BRIEF.md — questions for **future external independent audit**, which has NOT yet occurred.
- independent_equation_check.py — new SymPy symbolic check of core algebra.
- INDEPENDENT_EQUATION_RESULTS.json — output from running that check.
- PREVIOUS_EVIDENCE_ZIPS/ — untouched original evidence ZIPs (5 archived copies).
- SHA256SUMS — hashes of all files in this final bundle except the manifest itself.

Contents can be checked offline on Windows 10 / Python 3.12. External web reference links are supplied as citations, not runtime dependencies.
