#!/usr/bin/env python3
"""Independent sympy and fractional arithmetic checks of selected No.28 identities.
Does NOT use the previous No.28 verifier functions."""
import json, math
import sympy as sp
k, m, a, d, c, s = sp.symbols('k m a d c s', real=True)
# Derivative from raw hub ODE: the three classes of leaves: pi, phi, zero.
# Hub derivative k*s, leaf1'=-k*a*s, leaf2'=k*(a-d-1)*s,
# other leaves' summed velocity k*d*s; 
# cosine pi=-1, cosine phi=c, cosine zero=1.
h2 = sp.expand(k * (-( -k*a*s - k*s) + c * ( k*(a-d-1)*s - k*s ) + (k*d*s - (m-2)*k*s)))
expected = k**2*s*((3-m-2*c)+(1+c)*a+(1-c)*d)
assert sp.simplify(h2-expected)==0
# c=-1/3, s=2sqrt2/3 for exact-ternary reset.
S=2*sp.sqrt(2)/3
ternary = sp.expand(expected.subs({c:-sp.Rational(1,3),s:S}))
Q=sp.simplify(sp.Rational(3,2)*ternary/(k**2*S)+(3*m-11)/2)
assert sp.simplify(Q-a-2*d)==0
# integer-weight L generalization, solve (1+c)/(1-c)=1/(L+1)
L=sp.symbols('L',positive=True,integer=True)
cL=-L/(L+2)
assert sp.simplify((1+cL)/(1-cL)-1/(L+1))==0
# normalized hub raw trajectory Gronwall envelope via exact integral
u,t=sp.symbols('u t',real=True, nonnegative=True)
expr=sp.integrate(sp.exp(t-u)*(sp.exp(2*u)-1),(u,0,t))
assert sp.simplify(expr-(sp.exp(t)-1)**2)==0
# Graph two-point Gaussian testing with B(T): KL<=MB²/(2sigma²),
# Pinsker TV<=sqrt(M)B/(2sigma); TV>=1/2 => M>=sigma²/B².
amp=sp.simplify((2*S/3)*k**2)
assert sp.simplify(amp-4*sp.sqrt(2)*k*k/9)==0
# derivative observations: gaussian Chernoff R >= 8sig^2/A^2 log(2/delta)
assert sp.simplify(8/(amp**2)-sp.Rational(81,4)/k**4)==0
out={'status':'PASS selected algebraic identities; not full proof or independent human review',
     'normalized_ternary_second_jet':str(ternary),
     'integer_code_Q':str(Q),
     'gronwall_integral':str(expr),
     'direct_jet_lattice_gap':str(amp),
     'gaussian_R_constant':str(sp.simplify(8/(amp**2)))}
with open('INDEPENDENT_EQUATION_RESULTS.json','w') as f:json.dump(out,f,ensure_ascii=False,indent=2)
print(json.dumps(out,indent=2))
